
`timescale 1ns/1ps

function [6:0] popcount64;
    input [63:0] x;
    integer c;
    begin
        popcount64 = 0;
        for (c = 0; c < 64; c = c + 1)
            popcount64 = popcount64 + x[c];
    end
endfunction

module lfsr_generator_debug #(
    parameter [15:0] gen_id = 16'd0,
    parameter [255:0] lfsrseed = 256'hB9D34E1FA6275C8B71E4D0693A5BF28C6D421B9E87A30F5DE23194C758B6C1A4,
    parameter [3:0] poly1 = 4'd15,
    parameter [255:0] poly2_set = 256'hEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE,
    parameter [255:0] poly3_set = 256'hDDDDDDDDDDDDDCCCCCCCCCCCCBBBBBBBBBBBAAAAAAAAAA999999999888888887,
    parameter [255:0] poly4_set = 256'hCBA9876543210BA9876543210A98765432109876543210876543210765432106
)(
    input wire clk, rst_n, en, debug_mode, reseed_ext, reseed_int_en,
    input wire [15:0] wincnt,
    output wire [255:0] lfsrx16
);
    reg [15:0] wcnt;
    reg [255:0] lfsrox16 = lfsrseed ^ {16{gen_id}} ^ {{16{gen_id[15]}},gen_id[7:0]} ^ poly4_set;
    reg [255:0] lfsr_old;
    reg [255:0] lfsr_new;
    reg [63:0] bank1;
    reg [63:0] bank2;
    reg [63:0] bank3;
    reg [63:0] bank4;
    reg [95:0] bank_fidx1 = 96'h0123456789abcdef_01234567;
    reg [95:0] bank_fidx2 = 96'h89abcdef01234567_89abcdef;
    reg [95:0] bank_fidx3 = 96'hfedcba9876543210_fedcba98;
    reg [95:0] bank_fidx4 = 96'h13579bdf2468ace0_13579bdf;
    reg [31:0] bf1;
    reg [31:0] bf2;
    reg [31:0] bf3;
    reg [31:0] bf4;
    reg [63:0] bank1_prev;
    reg [63:0] bank2_prev;
    reg [63:0] bank3_prev;
    reg [63:0] bank4_prev;
    wire [6:0] pc1 = popcount64(bank1);
    wire [6:0] pc2 = popcount64(bank2);
    wire [6:0] pc3 = popcount64(bank3);
    wire [6:0] pc4 = popcount64(bank4);
    // 품질 조건
    wire [63:0] diff1 = bank1 ^ bank1_prev;
    wire zero1   = (bank1 == 64'd0);
    wire sparse1 = (pc1 < 7'd8);
    wire dense1  = (pc1 > 7'd56);
    wire stuck1  = (diff1 == 64'd0);
    wire [63:0] diff2 = bank2 ^ bank2_prev;
    wire zero2   = (bank2 == 64'd0);
    wire sparse2 = (pc2 < 7'd8);
    wire dense2  = (pc2 > 7'd56);
    wire stuck2  = (diff2 == 64'd0);
    wire [63:0] diff3 = bank3 ^ bank3_prev;
    wire zero3   = (bank3 == 64'd0);
    wire sparse3 = (pc3 < 7'd8);
    wire dense3  = (pc3 > 7'd56);
    wire stuck3  = (diff3 == 64'd0);
    wire [63:0] diff4 = bank4 ^ bank4_prev;
    wire zero4   = (bank4 == 64'd0);
    wire sparse4 = (pc4 < 7'd8);
    wire dense4  = (pc4 > 7'd56);
    wire stuck4  = (diff4 == 64'd0);
    // 종합 판단
    wire bad1 = zero1 | sparse1 | dense1 | stuck1;
    wire bad2 = zero2 | sparse2 | dense2 | stuck2;
    wire bad3 = zero3 | sparse3 | dense3 | stuck3;
    wire bad4 = zero4 | sparse4 | dense4 | stuck4;
    
    wire [63:0] rlfsr =
    {
        {bank1[15:0] ^ bank2[31:16] ^ bank3[47:32] ^ bank4[63:48]}
        ,{bank2[15:0] ^ bank3[31:16] ^ bank4[47:32] ^ bank1[63:48]}
        ,{bank3[15:0] ^ bank4[31:16] ^ bank1[47:32] ^ bank2[63:48]}
        ,{bank4[15:0] ^ bank1[31:16] ^ bank2[47:32] ^ bank3[63:48]}
    };
    
    wire [1:0] rlfsridx = wcnt[1:0];
    
    //wire [5:0] rsidx = wcnt[1:0] * 16;
    //wire reseed2 = ((wcnt ^ rlfsr[rsidx +:; 16]) & 16'h000f) == gen_id[3:0];
    
    wire reseed_internal;
    wire reseed_set;
    wire [15:0] wcnt_sw = debug_mode ? 16'd0 : (wincnt == wcnt ? wcnt : wincnt);
    
    assign reseed_internal = ((wcnt ^ rlfsr[rlfsridx << 4 +: 16]) & 16'h000f) == gen_id[3:0];
    assign reseed_set = reseed_ext | (reseed_internal & reseed_int_en);
    
    assign lfsrx16 = lfsrox16;
    
    integer pl, pl2, pl3, ps, lp, p0, p1, bsidx, beidx, b1, b2, b3, b4;
    
    always@(posedge clk) begin
        if(!rst_n) begin
            bank1 <= lfsrox16[63:0] ^ lfsrox16[127:64];
            bank2 <= lfsrox16[127:64] ^ lfsrox16[191:128];
            bank3 <= lfsrox16[191:128] ^ lfsrox16[255:192];
            bank4 <= lfsrox16[255:192] ^ lfsrox16[63:0];
            wcnt <= wincnt;
            bank1_prev <= 64'd0;
            bank2_prev <= 64'd0;
            bank3_prev <= 64'd0;
            bank4_prev <= 64'd0;
        end else if (en) begin
            bank1 <= (bad1 ? bank1 ^ 64'hA5A5A5A5A5A5A5A5 ^ {48'd0, wincnt} : lfsrox16[63:0] ^ lfsrox16[127:64]);
            bank2 <= (bad2 ? bank2 ^ 64'hA5A5A5A5A5A5A5A5 ^ {48'd0, wincnt} : lfsrox16[127:64] ^ lfsrox16[191:128]);
            bank3 <= (bad3 ? bank3 ^ 64'hA5A5A5A5A5A5A5A5 ^ {48'd0, wincnt} : lfsrox16[191:128] ^ lfsrox16[255:192]);
            bank4 <= (bad4 ? bank4 ^ 64'hA5A5A5A5A5A5A5A5 ^ {48'd0, wincnt} : lfsrox16[255:192] ^ lfsrox16[63:0]);
            wcnt <= wincnt;
            bank1_prev <= bank1;
            bank2_prev <= bank2;
            bank3_prev <= bank3;
            bank4_prev <= bank4;
        end
    end
    
    always @(*) begin
        lfsr_new = lfsrox16;
        lfsr_old = lfsrox16;
        bf1 = bank_fidx1;
        bf2 = bank_fidx2;
        bf3 = bank_fidx3;
        bf4 = bank_fidx4;
        for(p1 = 0;p1 < 16;p1 = p1 + 1) begin
            pl = p1 << 4;
            pl2 = p1 + 8;
            pl3 = p1 + 4;
            //ps = ((p1 ^ wcnt ^ gen_id ^ (lfsrox16[pl+7:pl] ^ lfsrox16[pl+15:pl+8])) << 2) & 8'hff;
            //lp = lfsrox16[pl + 7:pl+4] ^ lfsrox16[pl + 3:pl] ^ wcnt[3:0]  ^ gen_id[3:0];
            ps = ((p1 ^ wcnt_sw ^ gen_id ^ (lfsr_old[pl +: 8] ^ lfsr_old[pl2 +: 8])) << 2) & 8'hff;
            lp = lfsr_old[pl3 +: 4] ^ lfsr_old[pl +: 4] ^ wcnt_sw[3:0] ^ gen_id[3:0];
            bsidx = p1 * 6;
            b1 = bank_fidx1[bsidx +: 6];
            b2 = bank_fidx2[bsidx +: 6];
            b3 = bank_fidx3[bsidx +: 6];
            b4 = bank_fidx4[bsidx +: 6];
            bf1[bsidx +: 6] = ((pl + poly1) ^ lp) & 6'h3f;
            bf2[bsidx +: 6] = ((pl + poly2_set[ps +: 4]) ^ lp) & 6'h3f;
            bf3[bsidx +: 6] = ((pl + poly3_set[ps +: 4]) ^ lp) & 6'h3f;
            bf4[bsidx +: 6] = ((pl + poly4_set[ps +: 4]) ^ lp) & 6'h3f;
            lfsr_new[pl +: 16] =
            {
                //lfsrox16[pl + 14:pl],
                lfsr_old[pl +: 15],
                bank1[b1]
                ^ bank2[b2]
                ^ bank3[b3]
                ^ bank4[b4]
            } ^ wcnt_sw ^ (gen_id << 3) ^ {{8{gen_id[15]}},gen_id[7:0]};
        end
    end
    
    always @(posedge clk) begin
        if(!rst_n) begin
            lfsrox16 <= lfsrox16 ^ (gen_id << 3) ^ {{8{gen_id[15]}},gen_id[7:0]};
        end else if(en & !reseed_set) begin
            lfsrox16 <= lfsr_new;
            bank_fidx1 <= bf1;
            bank_fidx2 <= bf2;
            bank_fidx3 <= bf3;
            bank_fidx4 <= bf4;
        end else if(en & reseed_set) begin
        //end else if(en & reseed) begin
            lfsrox16[15:0] <= lfsrox16[15:0] ^ lfsrox16[31:16] ^ wcnt_sw ^ gen_id ^ {{8{gen_id[15]}},gen_id[7:0]};
            lfsrox16[31:16] <= lfsrox16[31:16] ^ lfsrox16[47:32] ^ wcnt_sw ^ gen_id ^ {{8{gen_id[15]}},gen_id[7:0]};
            lfsrox16[47:32] <= lfsrox16[47:32] ^ lfsrox16[63:48] ^ wcnt_sw ^ gen_id ^ {{8{gen_id[15]}},gen_id[7:0]};
            lfsrox16[63:48] <= lfsrox16[63:48] ^ lfsrox16[79:64] ^ wcnt_sw ^ gen_id ^ {{8{gen_id[15]}},gen_id[7:0]};
            lfsrox16[79:64] <= lfsrox16[79:64] ^ lfsrox16[95:80] ^ wcnt_sw ^ gen_id ^ {{8{gen_id[15]}},gen_id[7:0]};
            lfsrox16[95:80] <= lfsrox16[95:80] ^ lfsrox16[111:96] ^ wcnt_sw ^ gen_id ^ {{8{gen_id[15]}},gen_id[7:0]};
            lfsrox16[111:96] <= lfsrox16[111:96] ^ lfsrox16[127:112] ^ wcnt_sw ^ gen_id ^ {{8{gen_id[15]}},gen_id[7:0]};
            lfsrox16[127:112] <= lfsrox16[127:112] ^ lfsrox16[143:128] ^ wcnt_sw ^ gen_id ^ {{8{gen_id[15]}},gen_id[7:0]};
            lfsrox16[143:128] <= lfsrox16[143:128] ^ lfsrox16[159:144] ^ wcnt_sw ^ gen_id ^ {{8{gen_id[15]}},gen_id[7:0]};
            lfsrox16[159:144] <= lfsrox16[159:144] ^ lfsrox16[175:160] ^ wcnt_sw ^ gen_id ^ {{8{gen_id[15]}},gen_id[7:0]};
            lfsrox16[175:160] <= lfsrox16[175:160] ^ lfsrox16[191:176] ^ wcnt_sw ^ gen_id ^ {{8{gen_id[15]}},gen_id[7:0]};
            lfsrox16[191:176] <= lfsrox16[191:176] ^ lfsrox16[207:192] ^ wcnt_sw ^ gen_id ^ {{8{gen_id[15]}},gen_id[7:0]};
            lfsrox16[207:192] <= lfsrox16[207:192] ^ lfsrox16[223:208] ^ wcnt_sw ^ gen_id ^ {{8{gen_id[15]}},gen_id[7:0]};
            lfsrox16[223:208] <= lfsrox16[223:208] ^ lfsrox16[239:224] ^ wcnt_sw ^ gen_id ^ {{8{gen_id[15]}},gen_id[7:0]};
            lfsrox16[239:224] <= lfsrox16[239:224] ^ lfsrox16[255:240] ^ wcnt_sw ^ gen_id ^ {{8{gen_id[15]}},gen_id[7:0]};
            lfsrox16[255:240] <= lfsrox16[255:240] ^ lfsrox16[15:0] ^ wcnt_sw ^ gen_id ^ {{8{gen_id[15]}},gen_id[7:0]};
        end
    end
endmodule

module lfsr_mnfcompare #(
    parameter [15:0] mfid = 16'd0
)(
    input wire clk, rst_n, en,
    input wire [15:0] wincnt,
    input wire [15:0] lfsr_in,
    input wire [7:0] base,
    output reg yield_out
);
    //wire [15:0] lfsrmixer = (lfsr_in ^ wincnt ^ mfid ^ {{8{mfid[7]}},mfid[7:0]}) + (mfid << (mfid[1:0] + 16'd1));
    wire [15:0] lfsrmixer = (lfsr_in ^ (lfsr_in << 3) ^ (lfsr_in >> 5)) + (mfid << (mfid[1:0] + 16'd1)) + wincnt;
    wire [15:0] lfsrmixer2 = (lfsrmixer << 3) ^ (lfsrmixer >> 2) ^ lfsrmixer;
    wire [15:0] lfsrshift = {lfsrmixer2[3:0],lfsrmixer2[11:8],lfsrmixer2[7:4],lfsrmixer2[15:12]};
    wire [7:0] lfsr_fold = ((lfsrshift[15:8] ^ lfsrshift[7:0]) ^ (lfsrshift[15:8] >> 1)) ^ (lfsrshift[7:0] << 1);
    
    always @(posedge clk) begin
        if(!rst_n) begin
            yield_out <= 1'b0;
        end else if(en) begin
            //yield_out <= lfsr_fold < (base >> 3);
            yield_out <= (lfsr_fold < base);
        end
    end
endmodule

module acc8cnt_debug #(
    parameter b4lsb = 0,
    parameter b4msb = 3,
    parameter [b4msb:b4lsb] b4_0 = 4'd0,
    parameter b8lsb = 0,
    parameter b8msb = 7,
    parameter b16lsb = 0,
    parameter b16msb = 15,
    parameter [b16msb:b16lsb] b16_0 = 16'd0,
    parameter [b4msb:b4lsb] lv = 4'd0,
    parameter b128lsb = 0,
    parameter b128msb = 127,
    parameter carrybit = 3,
    parameter cntlsb = 0,
    parameter cntmsb = 2,
    parameter yclsb = 0,
    parameter ycmsb = 7,
    parameter ycnt = 8
)(
    input wire clk, rst_n, en,
    input wire [b4msb:b4lsb] en_rate_,
    input wire [ycmsb:yclsb] yields_chunk,
    input wire [b16msb:b16lsb] wincnt,
    output wire en_out,
    output reg carry8
    //output reg [1:0] evdetect
);

    reg [b4msb:b4lsb] ecnt;
    reg [b4msb:b4lsb] en_rate;
    reg [2:0] acc_cnt;
    wire [1:0] ac1 = yields_chunk[0] + yields_chunk[1];
    wire [1:0] ac2 = yields_chunk[2] + yields_chunk[3];
    wire [1:0] ac3 = yields_chunk[4] + yields_chunk[5];
    wire [1:0] ac4 = yields_chunk[6] + yields_chunk[7];
    wire [2:0] ac5 = {ac1[1],ac1} + {ac2[1],ac2};
    wire [2:0] ac6 = {ac3[1],ac3} + {ac4[1],ac4};
    wire [3:0] ac7 = {ac5[2],ac5} + {ac6[2],ac6};
    wire [3:0] sum = {acc_cnt[2],acc_cnt} + ac7;
    
    assign en_out = (ecnt <= en_rate) ? 1'b1 : 1'b0;
    
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            ecnt <= b4_0;
            en_rate <= b4_0;
            acc_cnt <= 3'b0;
            carry8 <= 1'b0;
            //ev <= 2'd0;
        end else if(en) begin
            if(b4_0 < en_rate_) begin
                en_rate <= en_rate_;
            end
            ecnt <= ((ecnt == 4'd15) ? 4'b0 : ecnt + 4'b1);
            if(ecnt < en_rate) begin
                //acc_cnt <= sum[2:0];
                acc_cnt <= sum[2:0];
                carry8 <= sum[3];
                //ev[1] = sum[3] | sum[2];
                //ev[0] = sum[3] | (~sum[2] & sum[1]);
            end
        end
    end
endmodule