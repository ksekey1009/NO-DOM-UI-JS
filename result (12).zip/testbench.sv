ㅣ`timescale 1ns/1ps

module tb_closed_loop;

// ------------------
reg clk, rst_n, en;
reg [15:0] wcnt;

reg  [15:0] alpha_target;
wire [7:0]  base;

// ------------------
// LUT inverse
// ------------------
alpha_to_base_inv lut_inv (
    .alpha_target(alpha_target),
    .base(base)
);

// ------------------
localparam N_CH = 16;

wire [255:0] S0;
wire [N_CH*8-1:0] yield_bus;
wire [N_CH-1:0] carry_vec;

// ------------------
// DUT
// ------------------
lfsr_generator_debug dut_gen (
    .clk(clk),
    .rst_n(rst_n),
    .en(en),
    .debug_mode(1'b0),
    .reseed_ext(1'b0),
    .reseed_int_en(1'b0),
    .wincnt(wcnt),
    .lfsrx16(S0)
);

genvar g,h;
generate
for(g=0; g<N_CH; g=g+1) begin: CH
    for(h=0; h<8; h=h+1) begin: CMP

        lfsr_mnfcompare #(.mfid(h)) cmp (
            .clk(clk),
            .rst_n(rst_n),
            .en(en),
            .wincnt(wcnt),
            .lfsr_in(S0[(h<<4)+:16]),
            .base(base),
            .yield_out(yield_bus[(g<<3)+h])
        );

    end

    acc8cnt_debug acc (
        .clk(clk),
        .rst_n(rst_n),
        .en(en),
        .en_rate_(4'd15),
        .yields_chunk(yield_bus[(g<<3)+:8]),
        .wincnt(wcnt),
        .en_out(),
        .carry8(carry_vec[g])
    );
end
endgenerate

// ------------------
always #5 clk = ~clk;

// ------------------
// α 측정
// ------------------
task measure_alpha;
    output real alpha_out;

    integer sum1, cnt;
    integer P1, P2, P4;

    reg [N_CH-1:0] c, d1, d2, d3, d4;

    real q, p1, p2, p4;

begin
    sum1=0; cnt=0;
    P1=0; P2=0; P4=0;

    d1=0; d2=0; d3=0; d4=0;

    // warmup
    repeat(500) @(posedge clk);

    // measurement
    repeat(2000) begin
        @(posedge clk);

        c = carry_vec;

        sum1 = sum1 + $countones(c);
        cnt  = cnt  + N_CH;

        P1 = P1 + $countones(c & d1);
        P2 = P2 + $countones(c & d2);
        P4 = P4 + $countones(c & d4);

        d4=d3; d3=d2; d2=d1; d1=c;
        wcnt = wcnt + 1;
    end

    q  = sum1*1.0/cnt;
    p1 = P1*1.0/cnt;
    p2 = P2*1.0/cnt;
    p4 = P4*1.0/cnt;

    alpha_out = 1.0 + 2.0*((p1-q*q)+(p2-q*q)+(p4-q*q))/(q*(1-q));
end
endtask

// ------------------
real alpha_meas;

// ------------------
initial begin
    clk=0; rst_n=0; en=0; wcnt=0;
    #20; rst_n=1; en=1;

    // ---------- 테스트 ----------
    integer t;

    for(t=0; t<6; t=t+1) begin

        case(t)
            0: alpha_target = 16'd410; //1.60
            1: alpha_target = 16'd460;
            2: alpha_target = 16'd512;
            3: alpha_target = 16'd600;
            4: alpha_target = 16'd650;
            5: alpha_target = 16'd700;
        endcase

        repeat(200) @(posedge clk);

        measure_alpha(alpha_meas);

        $display("--------------------------------------------------");
        $display("TARGET = %f", alpha_target/256.0);
        $display("BASE   = %0d", base);
        $display("MEAS   = %f", alpha_meas);
        $display("ERROR  = %f", alpha_meas - (alpha_target/256.0));
    end

    $finish;
end

endmodule